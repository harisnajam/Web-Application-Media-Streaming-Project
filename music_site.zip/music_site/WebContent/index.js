$(document).on("pagebeforeshow", "#signuppage", function(){
	$("#signupusername").val("");
	$("#signuppassword").val("");
});

$(document).on("pagebeforeshow", "#loginpage", function(){
	$("#loginusername").val("");
	$("#loginpassword").val("");
});