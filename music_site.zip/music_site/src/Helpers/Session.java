package Helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class Session {
	
	private static HttpSession mySession = null;
	private static HttpServletRequest myRequest = null;
	
	public static void initialize(HttpSession session, HttpServletRequest request) {
		
		mySession = session;
		myRequest = request;
		
	}
	
	private static void disable() {
		
		ServletContext context = myRequest.getSession().getServletContext();
		CreateConnection.setConnection(myRequest);
		Connection connection = (Connection)context.getAttribute("connection");
		PreparedStatement statement = null;
		ResultSet result = null;
		
		try {
			statement = connection.prepareStatement("SELECT * FROM users WHERE username = ?;");
			statement.setString(1, myRequest.getParameter("loginusername"));
			result = statement.executeQuery();
			
			if (result.next() == true) {
				statement = connection.prepareStatement("UPDATE users SET password = ? WHERE username = ?;");
				statement.setString(1, "xxxxxx");
				statement.setString(2, myRequest.getParameter("loginusername"));
				statement.execute();
			}
			
			result.close();
			statement.close();
			connection.close();
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
	}
	
	public static boolean isDisabled() {
			
		ServletContext context = myRequest.getSession().getServletContext();
		CreateConnection.setConnection(myRequest);
		Connection connection = (Connection)context.getAttribute("connection");
		PreparedStatement statement = null;
		ResultSet result = null;
		boolean disabled = false;
			
		try {
			statement = connection.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?;");
			statement.setString(1, myRequest.getParameter("loginusername"));
			statement.setString(2, "xxxxxx");
			result = statement.executeQuery();
			
			if (result.next() == true) {
				disabled = true;
			}
				
			result.close();
			statement.close();
			connection.close();
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
		return disabled;
		
	}
	
	public static boolean userExists() {
		
		ServletContext context = myRequest.getSession().getServletContext();
		CreateConnection.setConnection(myRequest);
		Connection connection = (Connection)context.getAttribute("connection");
		PreparedStatement statement = null;
		ResultSet result = null;
		boolean exists = false;
			
		try {
			statement = connection.prepareStatement("SELECT * FROM users WHERE username = ?;");
			statement.setString(1, myRequest.getParameter("loginusername"));
			result = statement.executeQuery();
			
			if (result.next() == true) {
				exists = true;
			}
				
			result.close();
			statement.close();
			connection.close();
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
		return exists;
		
	}
	
	public static void increment() {
		
		try {
			if (isDisabled() == false && userExists() == true) {
				if (mySession.getAttribute(myRequest.getParameter("loginusername")) == null) {
					mySession.setAttribute(myRequest.getParameter("loginusername"), 1);
				}
				else {
					mySession.setAttribute(myRequest.getParameter("loginusername"), (int)mySession.getAttribute(myRequest.getParameter("loginusername")) + 1);
					
					if ((int)mySession.getAttribute(myRequest.getParameter("loginusername")) == 3) {
						mySession.setAttribute(myRequest.getParameter("loginusername"), 0);
						disable();
					}
				}
			}
			else {
				mySession.setAttribute(myRequest.getParameter("loginusername"), 0);
			}
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
	}
	
	public static void reset() {
		
		if (mySession.getAttribute(myRequest.getParameter("loginusername")) != null) {
			mySession.setAttribute(myRequest.getParameter("loginusername"), 0);
		}
		
	}
	
	public static int attempts() {
		
		int attempts = 0;
		
		if (mySession.getAttribute(myRequest.getParameter("loginusername")) != null) {
			attempts = (int)mySession.getAttribute(myRequest.getParameter("loginusername"));
		}
		
		return attempts;
		
	}

}