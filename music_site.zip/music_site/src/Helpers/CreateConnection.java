package Helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class CreateConnection {
	
	public static void setConnection(HttpServletRequest request) {
		
		ServletContext context = request.getSession().getServletContext();
		String driver = "com.mysql.jdbc.Driver";
		String address = context.getInitParameter("address");
		String url = "jdbc:mysql://" + address + ":3306/";
		String database = context.getInitParameter("database");
		String username = context.getInitParameter("username");
		String password = context.getInitParameter("password");
		Connection connection = null;
		
		try {
			Class.forName(driver).newInstance();
			connection = DriverManager.getConnection(url + database, username, password);
			context.setAttribute("connection", connection);
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
	}

}