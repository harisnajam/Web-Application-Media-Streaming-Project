package Helpers;

public class Music {
	
	private static String[] titles = {
			"The Complex", "Where'd You Go", "Another World",
			"Cosmology", "Come As You Are", "Bitter Sweet Symphony",
			"Eye of the Tiger", "Imaginary Friend", "Evil Beauty",
			"Auditory Hallucination"
	};
	private static String[] sources = {
			"music/the_complex.m4a", "music/whered_you_go.m4a", "music/another_world.m4a",
			"music/cosmology.m4a", "music/come_as_you_are.m4a", "music/bitter_sweet_symphony.m4a",
			"music/eye_of_the_tiger.m4a", "music/imaginary_friend.m4a", "music/evil_beauty.m4a",
			"music/auditory_hallucination.m4a"
	};
	private static int amount = titles.length;
	
	public static int getAmount() {
		
		return amount;
		
	}
	
	public static String[] getTitles() {
		
		return titles;
		
	}
	
	public static String[] getSources() {
		
		return sources;
		
	}

}