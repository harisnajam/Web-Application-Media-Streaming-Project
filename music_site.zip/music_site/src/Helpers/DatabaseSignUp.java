package Helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class DatabaseSignUp {
	
	private static boolean valid = false;
	
	public static void verify(HttpServletRequest request) {
		
		ServletContext context = request.getSession().getServletContext();
		Connection connection = (Connection)context.getAttribute("connection");
		PreparedStatement statement = null;
		ResultSet result = null;
		
		try {
			statement = connection.prepareStatement("SELECT * FROM users WHERE username = ?;");
			statement.setString(1, request.getParameter("signupusername"));
			result = statement.executeQuery();
			
			if (result.next() == true) {
				valid = false;
			}
			else {
				statement = connection.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?);");
				statement.setString(1, request.getParameter("signupusername"));
				statement.setString(2, request.getParameter("signuppassword"));
				statement.execute();
				valid = true;
			}
			
			result.close();
			statement.close();
			connection.close();
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
	}
	
	public static boolean isValid() {
		
		return valid;
		
	}

}