package Helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

public class DatabaseLogin {
	
	private static boolean valid = false;
	
	public static void verify(HttpServletRequest request) {
		
		ServletContext context = request.getSession().getServletContext();
		Connection connection = (Connection)context.getAttribute("connection");
		PreparedStatement statement = null;
		ResultSet result = null;
		
		try {
			statement = connection.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?;");
			statement.setString(1, request.getParameter("loginusername"));
			statement.setString(2, request.getParameter("loginpassword"));
			result = statement.executeQuery();
			
			if (result.next() == true) {
				valid = true;
			}
			else {
				valid = false;
			}
			
			result.close();
			statement.close();
			connection.close();
		}
		catch (Exception exception) {
			System.err.println(exception.getMessage());
		}
		
	}
	
	public static boolean isValid() {
		
		return valid;
		
	}

}